<?php

/** --------------------------------------------------------------------------------
 * This repository class manages all the data absctration for purchases
 *
 * @package    Grow CRM
 * @author     NextLoop
 *----------------------------------------------------------------------------------*/

namespace App\Repositories;

use App\Models\Purchase;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Schema;
use Log;


class PurchasesRepository{



    /**
     * The template repository instance.
     */
    protected $purchase;

    /**
     * Inject dependecies
     */
    public function __construct(Purchase $purchase) {
        $this->purchase = $purchase;
    }


        /**
     * Search model
     * @param int $id optional for getting a single, specified record
     * @return object purchase collection
     */
    public function search($id = '') {

        $purchases = $this->purchase->newQuery();

        $purchases->selectRaw('*');

        $purchases->leftJoin('users', 'users.id', '=', 'purchases.purchase_creatorid');
        $purchases->leftJoin('clients', 'clients.client_id', '=', 'purchases.purchase_clientid');
        $purchases->leftJoin('projects', 'projects.project_id', '=', 'purchases.purchase_projectid');
        $purchases->leftJoin('suppliers', 'suppliers.supplier_id', '=', 'purchases.purchase_supplierid');

        // $purchases->leftJoin('users', 'users.id', '=', 'purchases.purchase_creatorid');


        //filters: id
        // if (is_numeric($id)) {
        //     $purchases->where('contract_template_id', $id);
        // }

        $purchases->orderBy('purchase_id', 'desc');


        // Get the results and return them.
        return $purchases->paginate(config('system.settings_system_pagination_limits'));
    }
}