<?php

/** --------------------------------------------------------------------------------
 * This repository class manages all the data absctration for templates
 *
 * @package    Grow CRM
 * @author     NextLoop
 *----------------------------------------------------------------------------------*/

namespace App\Repositories;

use App\Models\Supplier;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Schema;
use Log;


class SupplierRepository{



    /**
     * The template repository instance.
     */
    protected $supplier;

    /**
     * Inject dependecies
     */
    public function __construct(Supplier $supplier) {
        $this->supplier = $supplier;
    }


        /**
     * Search model
     * @param int $id optional for getting a single, specified record
     * @return object templates collection
     */
    public function search($id = '') {

        $supplier = $this->supplier->newQuery();

        $supplier->selectRaw('*');

        $supplier->leftJoin('users', 'users.id', '=', 'suppliers.supplier_created_by');
        $supplier->leftJoin('supplier_categories', 'supplier_category_id', '=', 'suppliers.supplier_categoryid');
        
        
        //filters: id
        if (is_numeric($id)) {
            $supplier->where('supplier_id', $id);
        }

        $supplier->orderBy('supplier_id', 'desc');


        // Get the results and return them.
        return $supplier->paginate(config('system.settings_system_pagination_limits'));
    }
}