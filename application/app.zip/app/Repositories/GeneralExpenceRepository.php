<?php

/** --------------------------------------------------------------------------------
 * This repository class manages all the data absctration for purchases
 *
 * @package    Grow CRM
 * @author     NextLoop
 *----------------------------------------------------------------------------------*/

namespace App\Repositories;

use App\Models\GeneralExpence;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Schema;
use Log;


class GeneralExpenceRepository{



    /**
     * The template repository instance.
     */
    protected $generalexpence;

    /**
     * Inject dependecies
     */
    public function __construct(GeneralExpence $generalexpence) {
        $this->generalexpence = $generalexpence;
    }


        /**
     * Search model
     * @param int $id optional for getting a single, specified record
     * @return object purchase collection
     */
    public function search($id = '') {

        $generalexpence = $this->generalexpence->newQuery();

        $generalexpence->selectRaw('*');

        /*$generalexpence->leftJoin('users', 'users.id', '=', 'purchases.purchase_creatorid');
        $generalexpence->leftJoin('clients', 'clients.client_id', '=', 'purchases.purchase_clientid');
        $generalexpence->leftJoin('projects', 'projects.project_id', '=', 'purchases.purchase_projectid');
        $generalexpence->leftJoin('suppliers', 'suppliers.supplier_id', '=', 'purchases.purchase_supplierid');*/

        // $purchases->leftJoin('users', 'users.id', '=', 'purchases.purchase_creatorid');


        //filters: id
        // if (is_numeric($id)) {
        //     $purchases->where('contract_template_id', $id);
        // }

        $generalexpence->orderBy('generalexpence_id', 'desc');


        // Get the results and return them.
        return $generalexpence->paginate(config('system.settings_system_pagination_limits'));
    }
}