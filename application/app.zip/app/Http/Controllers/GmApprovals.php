<?php 

/** --------------------------------------------------------------------------------
 * This controller manages all the business logic for purchase
 *
 * @package    Grow CRM
 * @author     NextLoop
 *----------------------------------------------------------------------------------*/

namespace App\Http\Controllers;

use App\Http\Controllers\Controller;
use App\Http\Responses\Purchases\GmApprovals\IndexResponse;
use App\Http\Responses\Purchases\GmApprovals\ChangeStatusResponse;
use App\Http\Responses\Purchases\GmApprovals\UpdateResponse;
use App\Http\Responses\Purchases\CreateResponse;
use App\Repositories\PurchasesRepository;
use App\Repositories\ClientRepository;
use App\Repositories\ProjectRepository;
use App\Repositories\SupplierRepository;

class GmApprovals extends Controller {
    
        /**
        * The purchase repository instance.
        */
        protected $purchaserepo;
        protected $clientrepo;
        protected $projectrepo;
        protected $supplierrepo;
        
        
        public function __construct(PurchasesRepository $purchaserepo,ClientRepository $clientrepo,ProjectRepository $projectrepo,SupplierRepository $supplierrepo){
            $this->purchaserepo = $purchaserepo;
            $this->clientrepo = $clientrepo;
            $this->projectrepo = $projectrepo;
            $this->supplierrepo = $supplierrepo;
            
        }

    /**
     * Display a listing of purchases
     * @return \Illuminate\Http\Response
     */
    public function index() {
        
        $purchase = $this->purchaserepo->search();

         //reponse payload
        $payload = [
            'page' => $this->pageSettings('purchase'),
            'purchase' => $purchase,
        ];

        //show the view
        return new IndexResponse($payload);
    }    
    
    
    public function create() {
        
        //get clients
        $client = $this->clientrepo->search();
        
        //get projects
        $project = $this->projectrepo->search();
        
        //get supplier
        $supplier = $this->supplierrepo->search();
        
        //reponse payload
        $payload = [
            'page' => $this->pageSettings('create'),
            'client' => $client,
            'project' => $project,
            'supplier' => $supplier, 
        ];
    
        //show the form
        return new CreateResponse($payload);
    }
    
    /**
     * Show the form for changing a gm Approvels status
     * @return \Illuminate\Http\Response
     */
    public function changeStatus() {
        
        //get the purchase
        $purchase = \App\Models\Purchase::Where('purchase_id', request()->route('gm-approvals'))->first();

        //reponse payload
        $payload = [
            'purchase' => $purchase,
        ];

        //show the form
        return new ChangeStatusResponse($payload);
    }
    
    /**
     * change status purchase status
     * @return \Illuminate\Http\Response
     */
    public function changeStatusUpdate() {

        //validate the purchases exists
        $purchase = \App\Models\Purchase::Where('purchase_id', request()->route('purchase'))->first();

        //old status
        $old_status = $purchase->purchase_status;


        //update the project
        $purchase->purchase_status = request('purchase_status');
        $purchase->save();
        
         //get refreshed purchase
        $purchases = $this->purchaserepo->search(request()->route('purchase'));
        $purchase = $purchases->first();
        
        dd($purchase);
    
        //reponse payload
        $payload = [
            'purchase' => $purchases,
            'purchase_id' => request()->route('purchase'),
        ];

        //show the form
        return new UpdateResponse($payload);
    }
    
        /**
     * basic page setting for this section of the app
     * @param string $section page section (optional)
     * @param array $data any other data (optional)
     * @return array
     */
    private function pageSettings($section = '', $data = []) {

        //common settings
        $page = [
            'crumbs' => [
                __('lang.procurement'),
                __('lang.gm_approvals')
            ],
            'meta_title' => __('lang.procurement'),
            'heading' => __('lang.gm_approvals'),
            'crumbs_special_class' => 'list-pages-crumbs',
            'page' => 'gm_approvals',
            'no_results_message' => __('lang.no_results_found'),
            'mainmenu_procurement' => 'active',
            'submenu_gm_approvals' => 'active',
            'sidepanel_id' => 'sidepanel-filter-gm-approvals',
            'dynamic_search_url' => url('gm-approvals/search?action=search&purchase_id=' . request('purchase_id')),
            'add_button_classes' => 'add-edit-gm-approvals-button',
            'loaGmApprovalstton_route' => 'gm-approvals',
            'source' => 'list',
        ];

        return $page;
    }
}
