<?php 

/** --------------------------------------------------------------------------------
 * This controller manages all the business logic for purchase
 *
 * @package    Grow CRM
 * @author     NextLoop
 *----------------------------------------------------------------------------------*/

namespace App\Http\Controllers;

use App\Http\Controllers\Controller;
use App\Repositories\GeneralExpenceRepository;
use App\Http\Responses\GeneralExpence\IndexResponse;
/*use App\Http\Responses\Purchases\IndexResponse;
use App\Http\Responses\Purchases\CreateResponse;
use App\Repositories\PurchasesRepository;
use App\Repositories\ClientRepository;
use App\Repositories\ProjectRepository;
use App\Repositories\SupplierRepository;*/
use Validator;

class GeneralExpence extends Controller {
    
       protected $generalexpencerepo;
        /*protected $clientrepo;
        protected $projectrepo;
        protected $supplierrepo;*/
        
        
        public function __construct(GeneralExpenceRepository $generalexpencerepo/*,ClientRepository $clientrepo,ProjectRepository $projectrepo,SupplierRepository $supplierrepo*/){
            $this->generalexpencerepo = $generalexpencerepo;
            /*$this->clientrepo = $clientrepo;
            $this->projectrepo = $projectrepo;
            $this->supplierrepo = $supplierrepo;*/
            
        }

    /**
     * Display a listing of purchases
     * @return \Illuminate\Http\Response
     */
    public function index() {
        
       $generalexpence = $this->generalexpencerepo->search();
        
         //reponse payload
        $payload = [
            'page' => $this->pageSettings('purchase'),
            'generalexpence' => $generalexpence,
        ];
        
        return new IndexResponse($payload);
    }    
    
    private function pageSettings($section = '', $data = []) {

        //common settings
        $page = [
            'crumbs' => [
                __('lang.procurement'),
                __('lang.generalexpences')
            ],
            'meta_title' => __('lang.procurement'),
            'heading' => __('lang.generalexpences'),
            'crumbs_special_class' => 'list-pages-crumbs',
            'page' => 'generalexpences',
            'no_results_message' => __('lang.no_results_found'),
            'mainmenu_procurement' => 'active',
            'submenu_generalexpences' => 'active',
            // 'submenu_purchase_request' => 'active',
            // 'submenu_gm_approvals' => 'active',
            'sidepanel_id' => 'sidepanel-filter-purchase',
            'dynamic_search_url' => url('purchase/search?action=search&purchase_id=' . request('purchase_id')),
            'add_button_classes' => 'add-edit-purchase-button',
            'load_more_button_route' => 'generalexpences',
            'source' => 'list',
        ];

        config([
            //visibility - add project buttton
            'visibility.list_page_actions_add_button' => true,
            //visibility - filter button
            'visibility.list_page_actions_filter_button' => false,
            //visibility - search field
            'visibility.list_page_actions_search' => false,
            //visibility - toggle stats
            'visibility.stats_toggle_button' => false,
            'visibility.left_menu_toggle_button' => true,
        ]);

        $page += [
            'add_modal_title' => __('lang.add_purchase'),
            'add_modal_create_url' => url('purchase/create?purchaseresource_id=' . request('purchaseresource_id') . '&purchaseresource_type=' . request('purchaseresource_type') . '&filter_category=' . request('filter_category')),
            'add_modal_action_url' => url('purchase'),
            'add_modal_action_ajax_class' => '',
            'add_modal_action_ajax_loading_target' => 'commonModalBody',
            'add_modal_action_method' => 'POST',
        ];

        if ($section == 'create') {
            $page += [
                'section' => 'create',
            ];
            return $page;
        }

        //return
        return $page;
    }
    
    
    
}
